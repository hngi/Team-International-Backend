from django.shortcuts import render
from django.http import HttpResponse
from .models import data
import json

# Create your views here.
def home(request):
    file = open('C:/Users/Vikas Rathour/Desktop/user-data.json').read()
    jsonData = json.loads(file)
    dests=[data() for i in range(10)]
    for i in range(10):
        dests[i].ID=''.join(jsonData[i]['user_id'])
        dests[i].first_name=''.join(jsonData[i]['user_first_name'])
        dests[i].last_name=''.join(jsonData[i]['user_last_name'])
        dests[i].email=''.join(jsonData[i]['user_email'])
        dests[i].gender=''.join(jsonData[i]['user_gender'])
    

    return render(request , 'home.html', {'dests':dests})