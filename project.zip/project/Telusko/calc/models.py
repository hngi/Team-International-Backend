from django.db import models

# Create your models here.
class data:
    ID : str
    first_name :str
    last_name : str
    gender : str
    email : str
    address : str
    logged : bool
    img : str

